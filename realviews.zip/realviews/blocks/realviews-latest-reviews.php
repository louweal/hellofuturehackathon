<?php

/**
 * Template:			realviews-latest-reviews.php
 * Description:			List of the latest reviews (or all reviews)
 */

echo realviews_latest_reviews_function(null, false);
