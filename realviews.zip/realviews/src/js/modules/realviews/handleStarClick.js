export const handleStarClick = function handleStarClick(ratingWrapper) {
    return rating;
};
