<?php
add_shortcode('realviews_num_reviews', 'realviews_num_reviews_function');
function realviews_num_reviews_function()
{
    return 5;
}
