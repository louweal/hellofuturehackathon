<?php

/**
 * 
 * Add custom Block Editor Block
 * 
 */

add_action('plugins_loaded', 'hederapay_block_init');
function hederapay_block_init()
{
    error_log("acf/init fired");
    error_log(dirname(plugin_dir_path(__FILE__)) . '/blocks/hederapay-transaction-button.php');

    // Check function exists.
    if (function_exists('acf_register_block_type')) {
        // Register the hederapay transaction button block.
        acf_register_block_type(array(
            'name'              => 'hederapay-transaction-button',
            'title'             => __('HederaPay Transaction Button', 'hfh'),
            'description'       => __('Button for transactions on the Hedera Network', 'hfh'),
            'render_template'   => dirname(plugin_dir_path(__FILE__)) . '/blocks/hederapay-transaction-button.php',
            'mode'              => 'edit',
            'category'          => 'common',
            'icon'              => 'admin-comments',
            'keywords'          => array('hederapay', 'hedera', 'transaction', 'button'),
        ));
    } else {
        error_log("acf_register_block_type doesn't exist.");
    }
}
