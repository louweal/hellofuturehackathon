<?php
/*
Plugin Name: HederaPay
Description: Integrate Hedera transactions into your WordPress website. 
Version: 0.1
Author: HashPress Pioneers
*/

// Exit if accessed directly.
if (!defined('ABSPATH')) {
    exit;
}

add_action('init', 'init_hederapay_function');

function init_hederapay_function()
{
    require_once plugin_dir_path(__FILE__) . 'lib/admin.php';
    require_once plugin_dir_path(__FILE__) . 'lib/enqueue.php';
    require_once plugin_dir_path(__FILE__) . 'lib/helpers.php';
    require_once plugin_dir_path(__FILE__) . 'lib/shortcodes.php';
    require_once plugin_dir_path(__FILE__) . 'lib/gutenberg.php';
    require_once plugin_dir_path(__FILE__) . 'lib/acf.php';
    require_once plugin_dir_path(__FILE__) . 'lib/footer.php';
}
