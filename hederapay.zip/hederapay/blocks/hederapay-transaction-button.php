<?php

/**
 * Template:			hederapay-transaction-button.php
 * Description:			Button for transactions on the Hedera Network
 */

echo hederapay_transaction_button_function(null, false);
